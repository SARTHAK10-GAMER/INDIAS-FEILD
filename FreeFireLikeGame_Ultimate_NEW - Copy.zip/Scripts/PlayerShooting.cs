using UnityEngine;

public class PlayerShooting : MonoBehaviour
{
    public Camera cam;
    public int damage = 20;
    public float range = 100f;

    void Update()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            RaycastHit hit;
            if (Physics.Raycast(cam.transform.position, cam.transform.forward, out hit, range))
            {
                if (hit.transform.GetComponent<HealthSystem>())
                {
                    hit.transform.GetComponent<HealthSystem>().TakeDamage(damage);
                }
            }
        }
    }
}