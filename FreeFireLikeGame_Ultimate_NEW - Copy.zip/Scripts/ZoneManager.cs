using UnityEngine;

public class ZoneManager : MonoBehaviour
{
    public Transform zone;
    public float shrinkRate = 0.1f;

    void Update()
    {
        if (zone.localScale.x > 1f)
            zone.localScale -= Vector3.one * shrinkRate * Time.deltaTime;
    }
}